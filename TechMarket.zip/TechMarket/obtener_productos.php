<?php
$conexion = new mysqli("localhost", "root", "", "techmarket");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$resultado = $conexion->query("CALL ObtenerProductos()");

echo "<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Lista de Productos</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f4f4f4; }
    </style>
</head>
<body>
    <h2>Lista de Productos</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Stock</th>
                <th>ID Vendedor</th>
            </tr>
        </thead>
        <tbody>";

while ($fila = $resultado->fetch_assoc()) {
    echo "<tr>
        <td>{$fila['id_producto']}</td>
        <td>{$fila['nombre']}</td>
        <td>{$fila['descripcion']}</td>
        <td>\${$fila['precio']}</td>
        <td>{$fila['stock']}</td>
        <td>{$fila['id_vendedor']}</td>
    </tr>";
}

echo "</tbody></table></body></html>";

$conexion->close();
?>
