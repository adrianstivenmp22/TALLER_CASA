<?php
$host = "localhost";
$user = "root";  // Cambia esto si tienes otro usuario
$pass = "";  // Cambia esto si tienes una contraseña en MySQL
$dbname = "TechMarket";

// Crear conexión
$conn = new mysqli($host, $user, $pass, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

?>
