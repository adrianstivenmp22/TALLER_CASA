<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_usuario = $_POST['id_usuario'];
    $id_producto = $_POST['id_producto'];
    $cantidad = $_POST['cantidad'];
    $total = $_POST['total'];

    $stmt = $conn->prepare("CALL InsertarCompra(?, ?, ?, ?)");
    $stmt->bind_param("iiid", $id_usuario, $id_producto, $cantidad, $total);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Compra registrada correctamente"]);
    } else {
        echo json_encode(["error" => "Error al registrar compra"]);
    }

    $stmt->close();
    $conn->close();
}
?>
