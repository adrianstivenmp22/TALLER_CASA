-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-03-2025 a las 04:31:48
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `techmarket`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarEstadoUsuario` (IN `p_id_usuario` INT, IN `p_nuevo_estado` VARCHAR(50))   BEGIN
    UPDATE Usuarios SET estado = p_nuevo_estado WHERE id_usuario = p_id_usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ConsultarUsuarioPorEmail` (IN `p_email` VARCHAR(255))   BEGIN
    SELECT * FROM Usuarios WHERE email = p_email;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ConsultarUsuariosActivos` ()   BEGIN
    SELECT * FROM Usuarios WHERE estado = 'activo';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ContarUsuariosPorEstado` ()   BEGIN
    SELECT estado, COUNT(*) AS total FROM Usuarios GROUP BY estado;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarUsuario` (IN `p_id_usuario` INT)   BEGIN
    UPDATE Usuarios SET estado = 'eliminado' WHERE id_usuario = p_id_usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarUsuario` (IN `p_nombre` VARCHAR(255), IN `p_email` VARCHAR(255), IN `p_password` VARCHAR(255), IN `p_estado` VARCHAR(50))   BEGIN
    INSERT INTO Usuarios (nombre, email, password, estado)
    VALUES (p_nombre, p_email, p_password, p_estado);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ModificarUsuario` (IN `p_id_usuario` INT, IN `p_nombre` VARCHAR(255), IN `p_email` VARCHAR(255), IN `p_estado` VARCHAR(50))   BEGIN
    UPDATE Usuarios 
    SET nombre = p_nombre, email = p_email, estado = p_estado
    WHERE id_usuario = p_id_usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerUsuarioPorID` (IN `p_id_usuario` INT)   BEGIN
    SELECT id_usuario, nombre, email, estado FROM Usuarios WHERE id_usuario = p_id_usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerUsuarios` ()   BEGIN
    SELECT id_usuario, nombre, email, estado FROM Usuarios ORDER BY nombre ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerUsuariosActivos` ()   BEGIN
    SELECT id_usuario, nombre, email FROM Usuarios WHERE estado = 'activo' ORDER BY nombre ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RestaurarUsuario` (IN `p_id_usuario` INT)   BEGIN
    UPDATE Usuarios SET estado = 'activo' WHERE id_usuario = p_id_usuario AND estado = 'eliminado';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ValidarUsuario` (IN `p_email` VARCHAR(255), IN `p_password` VARCHAR(255))   BEGIN
    SELECT id_usuario, nombre, estado 
    FROM Usuarios 
    WHERE email = p_email AND password = p_password AND estado = 'activo';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id_compra` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `fecha_compra` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id_compra`, `id_usuario`, `id_producto`, `cantidad`, `total`, `fecha_compra`) VALUES
(1, 1, 1, 1, 1200.00, '2025-03-13 02:24:43'),
(2, 3, 2, 1, 900.00, '2025-03-13 02:24:43'),
(3, 5, 3, 2, 500.00, '2025-03-13 02:24:43'),
(4, 7, 4, 1, 80.00, '2025-03-13 02:24:43'),
(5, 9, 5, 1, 50.00, '2025-03-13 02:24:43'),
(6, 1, 6, 1, 600.00, '2025-03-13 02:24:43'),
(7, 3, 7, 1, 150.00, '2025-03-13 02:24:43'),
(8, 5, 8, 1, 300.00, '2025-03-13 02:24:43'),
(9, 7, 9, 1, 750.00, '2025-03-13 02:24:43'),
(10, 9, 10, 1, 400.00, '2025-03-13 02:24:43');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id_inventario` int(11) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad_disponible` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id_inventario`, `id_producto`, `cantidad_disponible`) VALUES
(1, 1, 4),
(2, 2, 9),
(3, 3, 13),
(4, 4, 19),
(5, 5, 24),
(6, 6, 7),
(7, 7, 11),
(8, 8, 6),
(9, 9, 5),
(10, 10, 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `metodo_pago` enum('tarjeta','paypal','transferencia') DEFAULT NULL,
  `estado` enum('pendiente','completado','fallido') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id_pago`, `id_usuario`, `id_compra`, `metodo_pago`, `estado`) VALUES
(1, 1, 1, 'tarjeta', 'completado'),
(2, 3, 2, 'paypal', 'completado'),
(3, 5, 3, 'transferencia', 'pendiente'),
(4, 7, 4, 'tarjeta', 'completado'),
(5, 9, 5, 'paypal', 'fallido'),
(6, 1, 6, 'transferencia', 'completado'),
(7, 3, 7, 'tarjeta', 'pendiente'),
(8, 5, 8, 'paypal', 'completado'),
(9, 7, 9, 'transferencia', 'fallido'),
(10, 9, 10, 'tarjeta', 'completado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `id_vendedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre`, `descripcion`, `precio`, `stock`, `id_vendedor`) VALUES
(1, 'Laptop HP', 'Laptop HP con 16GB RAM y SSD de 512GB', 1200.00, 5, 2),
(2, 'iPhone 13', 'Teléfono Apple iPhone 13 con 128GB', 900.00, 10, 4),
(3, 'Monitor Samsung', 'Monitor LED Samsung 24 pulgadas', 250.00, 15, 6),
(4, 'Teclado Mecánico', 'Teclado mecánico RGB para gaming', 80.00, 20, 8),
(5, 'Mouse Logitech', 'Mouse inalámbrico Logitech', 50.00, 25, 10),
(6, 'Tablet Samsung', 'Tablet Samsung Galaxy Tab S7', 600.00, 8, 2),
(7, 'SSD 1TB', 'Disco sólido de 1TB NVMe', 150.00, 12, 4),
(8, 'Auriculares Sony', 'Auriculares con cancelación de ruido', 300.00, 7, 6),
(9, 'Cámara Canon', 'Cámara Canon EOS 200D', 750.00, 6, 8),
(10, 'Smartwatch Garmin', 'Smartwatch GPS con sensor de ritmo cardíaco', 400.00, 9, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `tipo` enum('cliente','vendedor') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `correo`, `tipo`) VALUES
(1, 'Juan Pérez', 'juan@mail.com', 'cliente'),
(2, 'María López', 'maria@mail.com', 'vendedor'),
(3, 'Carlos Ramírez', 'carlos@mail.com', 'cliente'),
(4, 'Ana Torres', 'ana@mail.com', 'vendedor'),
(5, 'Pedro Gómez', 'pedro@mail.com', 'cliente'),
(6, 'Luis Suárez', 'luis@mail.com', 'vendedor'),
(7, 'Elena Díaz', 'elena@mail.com', 'cliente'),
(8, 'Andrés Ríos', 'andres@mail.com', 'vendedor'),
(9, 'Laura Medina', 'laura@mail.com', 'cliente'),
(10, 'Fernando Vargas', 'fernando@mail.com', 'vendedor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL,
  `id_vendedor` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `fecha_venta` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id_venta`, `id_vendedor`, `id_producto`, `cantidad`, `total`, `fecha_venta`) VALUES
(1, 2, 1, 1, 1200.00, '2025-03-13 02:24:43'),
(2, 4, 2, 1, 900.00, '2025-03-13 02:24:43'),
(3, 6, 3, 2, 500.00, '2025-03-13 02:24:43'),
(4, 8, 4, 1, 80.00, '2025-03-13 02:24:43'),
(5, 10, 5, 1, 50.00, '2025-03-13 02:24:43'),
(6, 2, 6, 1, 600.00, '2025-03-13 02:24:43'),
(7, 4, 7, 1, 150.00, '2025-03-13 02:24:43'),
(8, 6, 8, 1, 300.00, '2025-03-13 02:24:43'),
(9, 8, 9, 1, 750.00, '2025-03-13 02:24:43'),
(10, 10, 10, 1, 400.00, '2025-03-13 02:24:43');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id_compra`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_producto` (`id_producto`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id_inventario`),
  ADD KEY `id_producto` (`id_producto`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id_pago`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_compra` (`id_compra`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`),
  ADD KEY `id_vendedor` (`id_vendedor`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id_venta`),
  ADD KEY `id_vendedor` (`id_vendedor`),
  ADD KEY `id_producto` (`id_producto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id_inventario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id_pago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_vendedor`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_vendedor`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
