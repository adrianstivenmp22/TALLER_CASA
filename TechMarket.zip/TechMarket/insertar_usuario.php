<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $tipo = $_POST['tipo'];

    $stmt = $conn->prepare("CALL InsertarUsuario(?, ?, ?)");
    $stmt->bind_param("sss", $nombre, $correo, $tipo);

    if ($stmt->execute()) {
        echo json_encode(["mensaje" => "Usuario registrado correctamente"]);
    } else {
        echo json_encode(["error" => "Error al registrar usuario"]);
    }

    $stmt->close();
    $conn->close();
}
?>
